import serial
import time
total_pumps = 5

#
# %.2d forces two integers as needed for daisy chained pumps
# \x0D

serial_port = 'COM5'
baud_rate   = '9600'

def open_serial():
    ser = serial.Serial(serial_port,
                        baud_rate,
                        stopbits=serial.STOPBITS_ONE, #icc changed from TWO
                        bytesize=serial.EIGHTBITS,
                        parity=serial.PARITY_NONE,
                        timeout=.1)
    #print ser.is_open
    ser.flushInput()
    ser.flushOutput()
    return ser

def find_pumps(tot_range=total_pumps):
    pumps = []
    ser = open_serial() #diff
    ser.flushOutput()
    ser.flushInput()

    for i in range(total_pumps):
        cmd = '%.2dSTP\r'%i
        cmd = '%.2dADDRESS\r'%i
        #cmd = '%.2dNVRAM NONE\r'%i
        print(cmd)
        ser.write(str.encode(cmd))
        read1=ser.readline()
        read2=ser.readline()
        print(read2)
        #print(type(read2.decode('utf-8'))) 
        if "Pump address is" in read2.decode('utf-8'):
            print("pump %i found" % i)
            pumps.append(i)
        #ser.flushOutput()
        #ser.flushInput()       
    print(pumps)
    ser.close()
    return pumps

def read_serial_1(ser):
    ser.readline()
    try:
        line = ser.readline().decode('utf-8')
    except:
        line = 'read error'
    ser.flushInput()
    ser.flushOutput()    
    return line,line

def read_serial_2(ser):
    #print 'reading serial'
    special = {b'<':'back',b'>':'fwd',b':':'stopped',b'*':'stalled'}
    
    ser.readline()
    print(ser.readline())
    line = ser.read()
    print(line)
    
    if line==b'?' or line==b'O' or line==b'E':
        print(ser.readline().strip())
        
    msg=b''  
    while(1):
        output = ser.read()
        for c in output:
            c = c.to_bytes(1, 'little')
            # print(c)
            line+=c
            # print(line)
            # line+=str.encode(c,encoding='ASCII') #KJ
            if c==b'\n':
                #print(line)
                msg = line
                # line = ''
                line = b' '
                break    
            if c in special.keys():
                #print(msg,line)
                return msg.decode('utf-8'), line.decode('utf-8')

def set_diameter(pump,dia):
    ser = open_serial()
    ser.flushInput()
    print('-------- setting diameter of pump %i as %s -----------'%(pump,dia))
    cmd = '%.2dDIAMETER %s\r'%(pump,dia) # harvard
    ser.write(str.encode(cmd))
    msg, status = read_serial_1(ser)
    print(msg, status)
    ser.close()
    
def get_diameter(pump):
    ser = open_serial()
    #ser.flushInput()
    print('-------- getting diameter of pump %i -----------' %pump)
    cmd = '%.2dDIAMETER\x0D'%(pump) # harvard
    #print(cmd)
    ser.write(str.encode(cmd))
    msg, status = read_serial_1(ser)
    #print(status)
    dia = msg.split('\r')[0].strip().split(":")[1]
    ser.close()
    print(dia)
    return(dia)
            
def set_rates(rates):
    ser = open_serial()
    
    for pump in rates.keys():
        #print '-------- set pump %i -----------' %pump
        rate = int(rates[pump])
        #print(rate)
        if rate < 0:
            direction = 'W'
            cmd = '%.2dWRATE %i %s\x0D'%(pump,abs(rate),'ul/h') # Reverse
            ser.write(str.encode(cmd))
        elif rate > 0:
            direction = 'I'
            cmd = '%.2dIRATE %i %s\x0D'%(pump,abs(rate),'ul/h') # Forward
            ser.write(str.encode(cmd))
        elif rate ==0:
            cmd = '%.2dSTP\x0D' %(pump)
            ser.write(str.encode(cmd))
        #print cmd
        msg, status = read_serial_1(ser)
        #print(msg)
    ser.close()
    
def run_all(rates):
    ser = open_serial()
    for pump in rates.keys():
        #print('-------- run pump %i -----------' %pump)
        rate = int(rates[pump])
        if rate ==0:
            #print 'stop'
            cmd = '%.2dSTP\x0D' %(pump)
        elif rate >0:
            #print 'run +'
            cmd = '%.2dIRUN\x0D' %(pump)
        elif rate <0:
            #print 'run -'
            cmd = '%.2dWRUN\x0D' %(pump)
        ser.write(str.encode(cmd))
        msg, status = read_serial_1(ser)
        #print(msg)
    ser.close()

               
def get_rates(rates):
    rates = dict((p,get_rate(p,rates).split('.')[0]) for p,r in iter(rates.items()))
    return(rates)

def get_rate(pump, old_rates):
    ser = open_serial()
    #print('-------- get rate pump %i -----------' %pump)
    rate = int(old_rates[pump])
    if rate >0:
        #print 'get +'
        cmd = '%.2dIRATE\x0D'%(pump)
        #print cmd
        ser.write(str.encode(cmd))
        output, status = read_serial_1(ser)
        #print status
    elif rate <0:
        #print 'get -'
        cmd = '%.2dWRATE\x0D'%(pump)
        #print cmd
        ser.write(str.encode(cmd))
        output, status = read_serial_1(ser)
        #print status
    else:
        #print 'pump stopped'
        ser.close()
        return '0'
    try:
        r = output.split('\r')[0].split(':')[1].split(' ')
        units = r[1]
        rate = r[0]
        if units==' ml/h':
            rate = rate * 1000 # convert to ul/h
    except:
        rate=-1
    ser.close()     
    #print("output: is " + str(rate) + units)
    return(str(rate))

def stop_pump(pump):
    ser = open_serial()
    #print("stopping pump %i" %pump)
    cmd = '%.2dSTP\x0D' %(pump)
    ser.write(str.encode(cmd))
    msg, status = read_serial_1(ser)
    #print(msg, status)
    ser.close()

def prime(pump):
    ser = open_serial()
    cmd = '%.2dIRATE %i %s\x0D'%(pump,10000,'ul/h')
    print(cmd)
    ser.write(str.encode(cmd))
    cmd = '%.2dIRUN\x0D'%(pump)
    ser.write(str.encode(cmd))
    msg, status = read_serial_1(ser)
    ser.close()
    
'''
#TO SET PUMP ADDRESS, SIMPLY RUN THIS, changing cmd address to 0-99
# You must lug directly into the pump you are addressing and
# make sure that the com port is correct in device manager

ser = serial.Serial('COM3',19200)
print(ser.name)       # check which port was really used
print(ser.isOpen())
cmd = 'ADDRESS %.2d\x0D'%(0)
print(cmd)
ser.write(str.encode(cmd))
print(ser.readline())
'''

'''
#### TESTING CODE 
#print('-----')
#pump = 0
ser = serial.Serial('COM3',19200)
print(ser.name)       # check which port was really used
print(ser.isOpen())
ser.close()


#rates = {0:100}
#set_rates(rates)
#run_all(rates)
#get_rates(rates)
#prime(0)

print('\n-----')
cmd = '%.2dIRATE %i %s\x0D'%(0,1000,'u/h')
cmd = '%.2dWRATE %i %s\x0D'%(0,1000,'u/h')
print(cmd)
ser.write(str.encode(cmd))
print(ser.readline())

print('\n-----')
cmd = '%.2dWRUN\x0D'%(0)
print(cmd)
ser.write(str.encode(cmd))
print(ser.readline())

print('\n-----')
cmd = '%.2dWRATE\x0D'%(0)
print(cmd)
ser.write(str.encode(cmd))
print(ser.readline())
print(ser.readline())


print('\n-----')
cmd = '%.2dSTP\x0D'%(0)
print(cmd)
ser.write(str.encode(cmd))
print(ser.readline())
print(ser.readline())


#print(read_serial(ser))
#read1=ser.read(10)
#print(read1)
ser.close()

# test set diameter
cmd = '%.2dDIAMETER\x0D'%(0)
dia = 8
set_diameter(pump,dia)
get_diameter(pump)
'''

#rates = {0:1000}
#pumps = set_rates(rates)
#rates = get_rates(ser,pumps)
