import serial
import time

serial_port = 'COM3'
baud_rate   = '9600'
pump_num=4

#### CAREFUL! PUMPS HAVE DIFFERENT COMS
# make sure that the com port is correct in device manager

ser = serial.Serial(serial_port,
                        baud_rate,
                        stopbits=serial.STOPBITS_ONE, #icc changed from TWO
                        bytesize=serial.EIGHTBITS,
                        parity=serial.PARITY_NONE,
                        timeout=1)

print(ser.name)       # check which port was really used
print(ser.isOpen())

## STEP 1: TURN ON NVRAM TO STORE PUMP NUM IN MEM
## STEP 2: POWER CYCLE
## STEP 3: COMMENT OUT NVRAM AND PUMP ASSIGNMENT AND CHECK ADDRESS
'''
cmd = '%.2dNVRAM ON\x0D'%pump_num
print(cmd)
ser.write(str.encode(cmd))
ser.flushInput()
ser.flushOutput()

cmd = 'ADDRESS %.2d\x0D'%(pump_num)
print(cmd)
ser.write(str.encode(cmd))
print(ser.readline())
print(ser.readline())
ser.flushInput()
ser.flushOutput()
'''
cmd = 'ADDRESS\x0D'
print(cmd)
ser.write(str.encode(cmd))
print(ser.readline())
print(ser.readline())
ser.flushInput()
ser.flushOutput()

cmd = '%.2dNVRAM NONE\x0D'%pump_num
print(cmd)
ser.write(str.encode(cmd))
ser.flushInput()
ser.flushOutput()

ser.close()

'''
#### TESTING CODE 
#print('-----')
#pump = 0
ser = serial.Serial('COM3',19200)
print(ser.name)       # check which port was really used
print(ser.isOpen())
ser.close()

#rates = {0:100}
#set_rates(rates)
#run_all(rates)
#get_rates(rates)
#prime(0)

print('\n-----')
cmd = '%.2dIRATE %i %s\x0D'%(0,1000,'u/h')
cmd = '%.2dWRATE %i %s\x0D'%(0,1000,'u/h')
print(cmd)
ser.write(str.encode(cmd))
print(ser.readline())

print('\n-----')
cmd = '%.2dWRUN\x0D'%(0)
print(cmd)
ser.write(str.encode(cmd))
print(ser.readline())

print('\n-----')
cmd = '%.2dWRATE\x0D'%(0)
print(cmd)
ser.write(str.encode(cmd))
print(ser.readline())
print(ser.readline())


print('\n-----')
cmd = '%.2dSTP\x0D'%(0)
print(cmd)
ser.write(str.encode(cmd))
print(ser.readline())
print(ser.readline())


#print(read_serial(ser))
#read1=ser.read(10)
#print(read1)
ser.close()

# test set diameter
cmd = '%.2dDIAMETER\x0D'%(0)
dia = 8
set_diameter(pump,dia)
get_diameter(pump)
'''

#rates = {0:1000}
#pumps = set_rates(rates)
#rates = get_rates(ser,pumps)
